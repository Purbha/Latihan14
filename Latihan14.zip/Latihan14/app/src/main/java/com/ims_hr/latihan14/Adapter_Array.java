package com.ims_hr.latihan14;

public class Adapter_Array {

    String Header = "";
    String Desc = "";
    String Val = "";

    public Adapter_Array(String header, String desc, String val) {
        this.Header = header;
        this.Desc = desc;
        this.Val = val;
    }

}
